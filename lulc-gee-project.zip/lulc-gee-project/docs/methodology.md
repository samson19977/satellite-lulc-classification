# Methodology — LULC Classification

## 1. Study Area
The Lake Victoria Basin spans parts of Uganda, Kenya, and Tanzania.
It covers approximately 2.5 million km² and includes highly diverse land cover
ranging from water bodies and montane forest to intensive smallholder cropland
and rapidly expanding urban centres.

## 2. Data Acquisition
- **Sensor**: Copernicus Sentinel-2 MSI Level-2A (Surface Reflectance)
- **GEE Collection**: `COPERNICUS/S2_SR_HARMONIZED`
- **Temporal filter**: 2023-01-01 → 2023-12-31
- **Cloud filter**: `CLOUDY_PIXEL_PERCENTAGE < 20`
- **Cloud masking**: QA60 band (bits 10 & 11 for clouds and cirrus)
- **Composite**: Pixel-wise median across all valid observations

## 3. Feature Engineering

| Feature | Bands / Formula | Rationale |
|---|---|---|
| Blue | B2 | Water, aerosol sensitivity |
| Green | B3 | Vegetation, water |
| Red | B4 | Vegetation red edge |
| NIR | B8 | Vegetation biomass |
| SWIR1 | B11 | Soil/moisture |
| SWIR2 | B12 | Geology, burned areas |
| NDVI | (B8−B4)/(B8+B4) | Vegetation vigour |
| NDWI | (B3−B8)/(B3+B8) | Open water |
| NDBI | (B11−B8)/(B11+B8) | Built-up surfaces |
| EVI | 2.5*(NIR−RED)/(NIR+6RED−7.5BLUE+1) | Canopy structure |

## 4. Training Samples
Ground-truth polygons were digitised in the GEE Code Editor using high-resolution
base imagery (Google Satellite). Minimum 30 polygons per class were digitised,
distributed across the study area to capture spectral variability.

## 5. Classification Algorithm
**Random Forest** (Breiman 2001) was chosen because:
- Robust to correlated features and outliers
- Handles mixed spectral classes well
- Provides feature importance scores
- Natively supported in GEE (`ee.Classifier.smileRandomForest`)

**Hyperparameters**:
- `numberOfTrees = 100`
- `variablesPerSplit = 4` (≈ √10 features)
- `minLeafPopulation = 5`
- `bagFraction = 0.7`

## 6. Accuracy Assessment
The labelled dataset was split 70/30 (train/test) using `randomColumn`.
A separate classifier was trained on the 70% split and evaluated on the 30% holdout.
Reported metrics: confusion matrix, overall accuracy, kappa, producer/consumer accuracy.

## 7. Area Calculation
`ee.Image.pixelArea()` gives exact per-pixel area in m².
`reduceRegion` with a grouped sum reducer aggregates area per class over the ROI.
Scale was set to 100 m for memory efficiency (results match 10 m export).

## 8. Limitations
- Training samples are operator-digitised — potential for human labelling error
- Annual median may blur seasonal land-cover transitions (e.g. seasonal floods)
- Mixed pixels at 10 m are still common at urban-vegetation boundaries
- Validation is spatial holdout, not a fully independent field campaign

## 9. Future Work
- Add SAR (Sentinel-1) features for cloud-penetrating capability
- Multi-temporal classification to detect seasonal changes
- Deep learning approaches (U-Net) using GEE + TensorFlow integration
- Field validation campaign for ground-truth accuracy
